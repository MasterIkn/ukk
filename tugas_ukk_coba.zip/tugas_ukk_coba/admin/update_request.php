<?php
// Menghubungkan ke database
include 'koneksi.php';

// Ambil ID dan status dari URL
$id = $_GET['id'];
$status = $_GET['status'];

// Validasi status
if ($status == 'setujui') {
    $remarks = 'Disetujui';
} elseif ($status == 'ditolak') {
    $remarks = 'Ditolak';
} else {
    die('Status tidak valid.');
}

// Update status pada tabel data_request
$query = "UPDATE data_request SET remarks = '$remarks' WHERE id = $id";
if (mysqli_query($koneksi, $query)) {
    // Redirect ke halaman yang sama setelah update
    header("Location: request_peminjaman.php");
    exit();
} else {
    echo "Error updating record: " . mysqli_error($koneksi);
}
?>
