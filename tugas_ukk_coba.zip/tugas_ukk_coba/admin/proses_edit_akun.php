<?php
include 'koneksi.php';

// Mengambil data yang diupdate dari form
$id = $_POST['id'];
$username = $_POST['username'];
$fullname = $_POST['fullname'];
$email = $_POST['email'];
$password = $_POST['password']; // Password kosongkan jika tidak diubah
$alamat = $_POST['alamat'];
$role = $_POST['role'];

// Jika password tidak diubah, biarkan password lama
if (empty($password)) {
    $query = "UPDATE akun SET username='$username', fullname='$fullname', email='$email', alamat='$alamat', role='$role' WHERE id='$id'";
} else {
    $query = "UPDATE akun SET username='$username', fullname='$fullname', email='$email', password='$password', alamat='$alamat', role='$role' WHERE id='$id'";
}

// Menjalankan query update
if (mysqli_query($koneksi, $query)) {
    // Redirect kembali ke halaman utama
    header("Location: buttons.php");
} else {
    // Menampilkan error jika gagal
    echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
}

// Menutup koneksi
mysqli_close($koneksi);
?>
