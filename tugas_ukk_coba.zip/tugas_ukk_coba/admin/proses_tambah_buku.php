<?php
// Mengaktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Menghubungkan ke database
require_once 'koneksi.php';

// Fungsi untuk upload foto
function uploadFoto()
{
    $namaFoto = $_FILES['foto']['name'];
    $ukuranFoto = $_FILES['foto']['size'];
    $error = $_FILES['foto']['error'];
    $tmpFoto = $_FILES['foto']['tmp_name'];

    if ($error === 4) {
        echo "<script>alert('Pilih gambar terlebih dahulu.');</script>";
        return false;
    }

    // Validasi ekstensi foto yang diizinkan
    $fotoValid = ['jpg', 'jpeg', 'png'];
    $ekstensiFoto = explode('.', $namaFoto);
    $ekstensiFoto = strtolower(end($ekstensiFoto));

    if (!in_array($ekstensiFoto, $fotoValid)) {
        echo "<script>alert('Yang anda upload bukan gambar.');</script>";
        return false;
    }

    // Validasi ukuran foto, maksimal 2MB
    if ($ukuranFoto > 2000000) {
        echo "<script>alert('Ukuran gambar terlalu besar. Maksimal 2MB');</script>";
        return false;
    }

    // Membuat nama file unik untuk foto
    $fileNameBaru = uniqid();
    $fileNameBaru .= '.';
    $fileNameBaru .= $ekstensiFoto;

    // Pastikan direktori "uploads" sudah ada
    if (!is_dir('uploads')) {
        mkdir('uploads');
    }

    // Pindahkan file gambar ke folder 'uploads/'
    if (move_uploaded_file($tmpFoto, 'uploads/' . $fileNameBaru)) {
        return $fileNameBaru;
    } else {
        echo "<script>alert('Terjadi kesalahan saat upload file.');</script>";
        return false;
    }
}

// Mengecek apakah form sudah disubmit
if (isset($_POST['tambah'])) {

    // Mengambil data dari form
    $kode_buku = htmlspecialchars($_POST['kode_buku']);
    $nama_buku = htmlspecialchars($_POST['nama_buku']);
    $pengarang = htmlspecialchars($_POST['pengarang']);
    $penerbit = htmlspecialchars($_POST['penerbit']);
    $tahun_terbit = htmlspecialchars($_POST['tahun_terbit']);
    $deskripsi = htmlspecialchars($_POST['deskripsi']);
    $kategori = htmlspecialchars($_POST['kategori']);

    // Validasi inputan, pastikan semua kolom diisi
    if (empty($kode_buku) || empty($nama_buku) || empty($pengarang) || empty($penerbit) || empty($deskripsi) || empty($kategori)) {
        echo "<script>alert('Pastikan anda sudah mengisi semua formulir.');window.location='?p=buku';</script>";
        exit();
    }

    // Upload foto sampul buku
    $foto = uploadFoto();
    if (!$foto) {
        // Jika upload foto gagal, hentikan proses
        exit();
    }

    // Membuat query INSERT untuk menambahkan data buku
    $sql = "INSERT INTO buku (kode_buku, nama_buku, pengarang, penerbit, tahun_terbit, deskripsi, kategori, foto) 
            VALUES ('$kode_buku', '$nama_buku', '$pengarang', '$penerbit', '$tahun_terbit', '$deskripsi', '$kategori', '$foto')";

    // Debug: Menampilkan query untuk memeriksa formatnya
    echo $sql; // Ini untuk memeriksa apakah query sudah benar

    // Mengeksekusi query dan memeriksa apakah berhasil
    if ($koneksi->query($sql) === TRUE) {
        // Jika berhasil, tampilkan pesan sukses
        header("Location: cards.php?p=buku"); // Ganti 'card.php' sesuai dengan path file kamu
        exit(); 
    } else {
        // Jika gagal, tampilkan pesan error
        echo "<script>alert('Data Gagal Ditambahkan. Error: " . $koneksi->error . "');</script>";
    }
}
?>
