

<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
  <title>SMKN 1 Mejayan</title>
  <link rel="icon" href="images/logo.png">
</head>
<body>
    <nav class="bg-white dark:bg-gray-900 fixed w-full z-20 top-0 start-0 border-b border-gray-200 dark:border-gray-600">
        <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
            <a class="flex items-center space-x-3 rtl:space-x-reverse">
                <img src="assets/img/logo.png" class="h-16" alt="unipma Logo">
                <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">E-perpus SMKN 1 MEJAYAN</span>
            </a>
        </div>
    </nav>   

    <section class="relative py-10 mt-16 bg-gray-50 sm:py-16 lg:py-24">
        <div class="absolute inset-0 bg-gray-900/20"></div>
    
        <div class="relative max-w-lg px-4 mx-auto sm:px-0">
            <div class="overflow-hidden bg-white rounded-md shadow-md">
                <div class="px-4 py-6 sm:px-8 sm:py-7">
                    <div class="text-center">
                        <h2 class="text-3xl font-bold text-gray-900">Selamat Datang</h2>
                        <p class="mt-2 text-base text-gray-600">Di website Perpustakaan Digital SMKN 1 Mejayan</p>
                    </div>
    
                    <form action="  proses_login.php" method="POST" class="mt-8">
                        <div class="space-y-5">
                            <div>
                                <label for="email" class="text-base font-medium text-gray-900"> Email address </label>
                                <div class="mt-2.5">
                                    <input type="email" name="email" id="email" placeholder="Masukkan Email Anda" class="block w-full p-4 text-black placeholder-gray-500 transition-all duration-200 bg-white border border-gray-200 rounded-md focus:outline-none focus:border-blue-600 caret-blue-600" required />
                                </div>
                            </div>
    
                            <div>
                                <div class="flex items-center justify-between">
                                    <label for="password" class="text-base font-medium text-gray-900"> Password </label>
                                    <a href="#" class="text-sm font-medium transition-all duration-200 text-blue-600  hover:underline"> Forgot password? </a>
                                </div>
                                <div class="mt-2.5">
                                    <input type="password" name="password" id="password" placeholder="Masukkan Password Anda" class="block w-full p-4 text-black placeholder-gray-500 transition-all duration-200 bg-white border border-gray-200 rounded-md focus:outline-none focus:border-blue-600 caret-blue-600" required />
                                </div>


                        <p class="text-gray-800 text-sm !mt-8 text-center">Login Sebagai Siswa? <a href="../index.php" class="text-blue-600 hover:underline ml-1 whitespace-nowrap font-semibold">Login</a></p>
                            </div>
    
                            <div>
                                <button type="submit" class="inline-flex items-center justify-center w-full px-4 py-4 text-base font-semibold text-white transition-all duration-200 bg-blue-600 border border-transparent rounded-md focus:outline-none hover:bg-blue-700 focus:bg-blue-700">Log in</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <footer class="bg-white rounded-lg shadow dark:bg-gray-900 m-4">
        <div class="w-full max-w-screen-xl mx-auto p-4 md:py-8">
            <div class="sm:flex sm:items-center sm:justify-between">
                <a  class="flex items-center mb-4 sm:mb-0 space-x-3 rtl:space-x-reverse">
                    <img src="assets/img/logo.png" class="h-8" alt="unipma logo" />
                    <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">SMKN 1 Mejayan</span>
                </a>
                <ul class="flex flex-wrap items-center mb-6 text-sm font-medium text-gray-500 sm:mb-0 dark:text-gray-400">
                    <li><a href="#" class="hover:underline me-4 md:me-6">Youtube</a></li>
                    <li><a href="#" class="hover:underline me-4 md:me-6">Instagram</a></li>
                    <li><a href="#" class="hover:underline me-4 md:me-6">Facebook</a></li>
                    <li><a href="#" class="hover:underline">Tiktok</a></li>
                </ul>
            </div>
            <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
            <span class="block text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2024 <a href="https://flowbite.com/" class="hover:underline">MR.Sudar</a>. All Rights Reserved.</span>
        </div>
    </footer>

    <!-- <script type="text/javascript">
    // Jika halaman ini dimuat ulang setelah login, redirect ke halaman dashboard
    if (performance.navigation.type == 2) {  // Cek apakah halaman dimuat ulang dengan tombol "Back"
        window.location.href = "/index.php";  // Redirect ke halaman dashboard
    }
</script> -->

</body>
</html>
