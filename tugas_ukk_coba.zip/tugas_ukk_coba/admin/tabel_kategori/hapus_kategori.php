<?php

include'../koneksi.php';
if (isset($_GET['kategori_id'])) {
    $kategori_id = $_GET['kategori_id'];

    // Hapus kategori dari database
    $query = "DELETE FROM kategoribuku WHERE kategori_id = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param('i', $kategori_id);

    if ($stmt->execute()) {
        header('Location: kategori.php'); // Redirect setelah menghapus kategori
    } else {
        echo "Gagal menghapus kategori.";
    }
}
?>
