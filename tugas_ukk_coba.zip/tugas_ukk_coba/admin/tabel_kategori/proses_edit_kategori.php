<?php

include'../koneksi.php';
if (isset($_POST['edit'])) {
    $kategori_id = $_POST['kategori_id'];
    $nama_kategori = $_POST['nama_kategori'];

    // Update kategori di database
    $query = "UPDATE kategoribuku SET nama_kategori = ? WHERE kategori_id = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param('si', $nama_kategori, $kategori_id);

    if ($stmt->execute()) {
        header('Location: tabel_kategori.php'); // Redirect kembali ke halaman kategori
    } else {
        echo "Gagal mengupdate kategori.";
    }
}
?>
