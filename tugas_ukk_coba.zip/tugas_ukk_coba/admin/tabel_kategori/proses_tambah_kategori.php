<?php
// Include koneksi ke database
include('../koneksi.php'); // Pastikan file koneksi sudah benar

if (isset($_POST['tambah'])) {
    // Ambil nama kategori dari form
    $nama_kategori = $_POST['nama_kategori'];

    // Query untuk menambahkan kategori ke dalam database
    $query = "INSERT INTO kategoribuku (nama_kategori) VALUES ('$nama_kategori')";

    if ($koneksi->query($query)) {
        echo "<script>alert('Kategori berhasil ditambahkan!'); window.location.href = 'tabel_kategori.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan kategori!'); window.location.href = 'index.php';</script>";
    }
}
?>
