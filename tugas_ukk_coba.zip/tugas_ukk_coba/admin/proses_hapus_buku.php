<?php
// Menghubungkan ke database
require_once 'koneksi.php';

// Mengecek apakah ada parameter kode_buku yang diterima
if (isset($_GET['kode_buku'])) {
    $kode_buku = $_GET['kode_buku'];

    // Query untuk menghapus data buku berdasarkan kode_buku
    $query = "DELETE FROM buku WHERE kode_buku = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("s", $kode_buku); // Mengikat parameter

    // Mengeksekusi query
    if ($stmt->execute()) {
        // Jika berhasil menghapus data, arahkan ke halaman daftar buku dengan pesan sukses
        echo "<script>alert('Buku berhasil dihapus.'); window.location.href='index.php';</script>";
    } else {
        // Jika gagal menghapus data, tampilkan pesan error
        echo "<script>alert('Gagal menghapus buku.'); window.location.href='index.php';</script>";
    }

    // Menutup statement dan koneksi
    $stmt->close();
    $koneksi->close();
} else {
    // Jika kode_buku tidak diterima, redirect ke halaman daftar buku
    echo "<script>window.location.href='index.php';</script>";
}
?>
