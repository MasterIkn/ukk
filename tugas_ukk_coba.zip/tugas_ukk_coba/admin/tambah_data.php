<?php
// Koneksi ke database
include 'koneksi.php';

// Mengambil data dari form
$username = $_POST['username'];
$fullname = $_POST['fullname'];
$email = $_POST['email'];
$password = $_POST['password']; // Tanpa hashing
$alamat = $_POST['alamat'];
$role = $_POST['role'];

// Query untuk menambahkan data akun baru
$query = "INSERT INTO akun (username, fullname, email, password, alamat, role) 
          VALUES ('$username', '$fullname', '$email', '$password', '$alamat', '$role')";

// Menjalankan query
if (mysqli_query($koneksi, $query)) {
    // Redirect ke halaman utama setelah sukses
    header("Location: buttons.php");
} else {
    // Menampilkan pesan error jika gagal
    echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
}

// Menutup koneksi
mysqli_close($koneksi);
?>
