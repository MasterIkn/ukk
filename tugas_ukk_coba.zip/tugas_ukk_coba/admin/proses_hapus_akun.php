<?php
include 'koneksi.php';

// Mengecek apakah ID akun ada di URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Menghapus akun berdasarkan ID
    $query = "DELETE FROM akun WHERE id='$id'";

    if (mysqli_query($koneksi, $query)) {
        // Redirect kembali ke halaman utama setelah sukses
        header("Location: buttons.php");
    } else {
        // Menampilkan error jika gagal
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
}

// Menutup koneksi
mysqli_close($koneksi);
?>
