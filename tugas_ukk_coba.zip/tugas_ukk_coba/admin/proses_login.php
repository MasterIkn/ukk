<?php
// Mengaktifkan session PHP
session_start();

// Menghubungkan dengan koneksi
include 'koneksi.php';

// Menangkap data yang dikirim dari form
$email = $_POST['email'];
$password = $_POST['password'];

// Menyeleksi data user berdasarkan email dan password yang sesuai
$data = mysqli_query($koneksi, "SELECT * FROM akun WHERE email='$email' AND password='$password'");

// Menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);

// Jika login berhasil
if ($cek > 0) {
    // Mengambil data pengguna
    $user = mysqli_fetch_assoc($data);

    // Menyimpan email dan status login di session
    $_SESSION['email'] = $email;
    $_SESSION['status'] = "login";
    $_SESSION['role'] = $user['role']; // Menyimpan role ke dalam session

    // Redirect berdasarkan role
    if ($_SESSION['role'] == 'Admin') {
        header("Location: index.php");
    } elseif ($_SESSION['role'] == 'petugas') {
        header("Location: ../petugas/index.php");
    } else {
        // Jika role tidak dikenal, bisa diarahkan ke halaman lain
        header("Location: ../user/index.php");
    }
    exit();
} else {
    // Jika login gagal, kembali ke halaman login dengan pesan error
    header("Location: ../index.php?pesan=gagal");
    exit();
}
?>
