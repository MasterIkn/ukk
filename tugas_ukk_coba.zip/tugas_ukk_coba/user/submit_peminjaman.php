<?php
// Mulai session
session_start();

// Menghubungkan ke database
include '../admin/koneksi.php';

// Mengecek apakah pengguna sudah login
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    // Mengambil data dari form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $bookName = $_POST['bookName'];
    $borrowDate = $_POST['borrowDate'];  // Tanggal peminjaman
    $borrowDuration = $_POST['borrowDuration'];  // Lama peminjaman
    $returnDate = date('Y-m-d', strtotime($borrowDate . ' + ' . $borrowDuration . ' days'));  // Menghitung tanggal pengembalian
    $remarks = "request";  // Set status keterangan menjadi "Request"

    // Cek apakah buku ini sudah dipinjam oleh user dengan status "Aktif"
    $checkQuery = "SELECT * FROM data_request WHERE name = '$name' AND email = '$email' AND book_name = '$bookName' AND status = 'Aktif'";
    $checkResult = mysqli_query($koneksi, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        // Jika ditemukan peminjaman aktif, tampilkan pesan error
        echo "<script>alert('Anda sudah meminjam buku ini dan statusnya masih aktif. Anda tidak bisa meminjamnya lagi.');</script>";
        echo "<script>window.history.back();</script>";  // Kembali ke halaman sebelumnya
        exit();
    }

    // Query untuk menyimpan data ke tabel data_request
    $query = "INSERT INTO data_request (name, email, book_name, borrow_date, return_date, remarks, borrow_duration)
              VALUES ('$name', '$email', '$bookName', '$borrowDate', '$returnDate', '$remarks', '$borrowDuration')";

    // Eksekusi query
    if (mysqli_query($koneksi, $query)) {
        // Jika berhasil disimpan, arahkan ke halaman index.php
        header("Location: index.php");  // Redirect ke halaman index.php
        exit();
    } else {
        // Jika ada error saat menyimpan data
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
} else {
    // Jika belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}
?>
