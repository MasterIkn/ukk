<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Peminjaman Buku</title>
    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100">

    <!-- Navbar -->
    <nav class="bg-white border-b shadow-md sticky top-0 z-50">
        <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
            <a class="flex items-center space-x-3 rtl:space-x-reverse">
                <img src="/assets/img/logo.png" class="h-8" alt="Logo" />
                <span class="self-center text-2xl font-semibold text-gray-900">E-Library</span>
            </a>

            <!-- Profile Dropdown Button -->
            <div class="relative">
                <button type="button" class="flex text-sm bg-gray-800 rounded-full focus:ring-4 focus:ring-gray-300" id="user-menu-button">
                    <span class="sr-only">Open user menu</span>
                    <img class="w-8 h-8 rounded-full" src="/docs/images/people/profile-picture-3.jpg" alt="user photo">
                </button>

                <!-- Dropdown menu -->
                <div class="hidden absolute right-0 z-50 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg" id="user-dropdown">
                    <div class="px-4 py-3">
                        <span class="block text-sm text-gray-900">Bonnie Green</span>
                        <span class="block text-sm text-gray-500 truncate">name@flowbite.com</span>
                    </div>
                    <ul class="py-2">
                        <li><a href="index.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Dashboard</a></li>
                        <li><a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">History peminjaman</a></li>
                        <li><a href="ajuan_peminjaman.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Ajuan Peminjaman</a></li>
                        <li><a href="../admin/logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- Script for handling dropdown -->
    <script>
        const userMenuButton = document.getElementById('user-menu-button');
        const userDropdown = document.getElementById('user-dropdown');

        userMenuButton.addEventListener('click', function() {
            // Toggle the display of the dropdown menu
            userDropdown.classList.toggle('hidden');
        });

        // Close the dropdown if the user clicks outside of it
        window.addEventListener('click', function(event) {
            if (!userMenuButton.contains(event.target) && !userDropdown.contains(event.target)) {
                userDropdown.classList.add('hidden');
            }
        });
    </script>

    <!-- Section with Status Buku and Table -->
    <section class="px-4 py-8 mt-6">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Status Buku</h2>

        <!-- Table -->
        <div class="overflow-x-auto bg-white shadow-md rounded-lg border border-gray-200">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-gray-600">No</th>
                        <th class="px-4 py-2 text-left text-gray-600">Nama Buku</th>
                        <th class="px-4 py-2 text-left text-gray-600">Waktu Peminjaman</th>
                        <th class="px-4 py-2 text-left text-gray-600">Status Peminjaman</th>
                        <th class="px-4 py-2 text-left text-gray-600">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Row 1 -->
                    <tr class="border-t">
                        <td class="px-4 py-2 text-gray-800">1</td>
                        <td class="px-4 py-2 text-gray-800">JavaScript untuk Pemula</td>
                        <td class="px-4 py-2 text-gray-800">01-11-2024</td>
                        <td class="px-4 py-2 text-green-600">Disetujui</td>
                        <td class="px-4 py-2 flex space-x-2">
                            <button class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:ring-2 focus:ring-green-500">Kembalikan</button>
                            <button class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500">Baca</button>
                            <button class="px-4 py-2 text-sm font-medium text-white bg-yellow-600 rounded-md hover:bg-yellow-700 focus:ring-2 focus:ring-yellow-500">Ulasan</button>
                        </td>
                    </tr>
                    <!-- Row 2 -->
                    <tr class="border-t">
                        <td class="px-4 py-2 text-gray-800">2</td>
                        <td class="px-4 py-2 text-gray-800">HTML & CSS Mastery</td>
                        <td class="px-4 py-2 text-gray-800">02-11-2024</td>
                        <td class="px-4 py-2 text-red-600">Tidak Disetujui</td>
                        <td class="px-4 py-2 flex space-x-2">
                            <button class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:ring-2 focus:ring-green-500">Kembalikan</button>
                            <button class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500">Baca</button>
                            <button class="px-4 py-2 text-sm font-medium text-white bg-yellow-600 rounded-md hover:bg-yellow-700 focus:ring-2 focus:ring-yellow-500">Ulasan</button>
                        </td>
                    </tr>
                    <!-- Row 3 -->
                    <tr class="border-t">
                        <td class="px-4 py-2 text-gray-800">3</td>
                        <td class="px-4 py-2 text-gray-800">Belajar ReactJS</td>
                        <td class="px-4 py-2 text-gray-800">03-11-2024</td>
                        <td class="px-4 py-2 text-green-600">Disetujui</td>
                        <td class="px-4 py-2 flex space-x-2">
                            <button class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:ring-2 focus:ring-green-500">Kembalikan</button>
                            <button class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500">Baca</button>
                            <button class="px-4 py-2 text-sm font-medium text-white bg-yellow-600 rounded-md hover:bg-yellow-700 focus:ring-2 focus:ring-yellow-500">Ulasan</button>
                        </td>
                    </tr>
                    <!-- Row 4 -->
                    <tr class="border-t">
                        <td class="px-4 py-2 text-gray-800">4</td>
                        <td class="px-4 py-2 text-gray-800">Node.js untuk Backend</td>
                        <td class="px-4 py-2 text-gray-800">04-11-2024</td>
                        <td class="px-4 py-2 text-red-600">Tidak Disetujui</td>
                        <td class="px-4 py-2 flex space-x-2">
                            <button class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:ring-2 focus:ring-green-500">Kembalikan</button>
                            <button class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500">Baca</button>
                            <button class="px-4 py-2 text-sm font-medium text-white bg-yellow-600 rounded-md hover:bg-yellow-700 focus:ring-2 focus:ring-yellow-500">Ulasan</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

</body>

</html>
