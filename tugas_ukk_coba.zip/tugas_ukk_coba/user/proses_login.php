
<?php 
// mengaktifkan session php
session_start();
 
// menghubungkan dengan koneksi
include '../admin/koneksi.php';
 
// menangkap data yang dikirim dari form
$email = $_POST['Email'];
$password = $_POST['Password'];
 
// menyeleksi data admin dengan username dan password yang sesuai
$data = mysqli_query($koneksi,"select * from user where Email='$email' and Password='$password'");
 
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);
 
if($cek > 0){
	$_SESSION['Email'] = $email;
	$_SESSION['status'] = "login";
	header("location:index.php");
}else{
	header("location:../index.php?pesan=gagal");
}
?>