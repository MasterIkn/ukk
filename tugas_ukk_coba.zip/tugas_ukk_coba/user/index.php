<?php
session_start();

// Cek apakah pengguna sudah login, jika tidak redirect ke halaman login
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("Location: ../index.php");
    exit();
}
// Mencegah halaman ini disimpan dalam cache
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
?>


<!doctype html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- google font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
    rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
  <style>
    body {
      font-family: Poppins, sans-serif;
    }
    .active {
            color: blue; /* Warna teks saat aktif */
        }
        html {
            scroll-behavior: smooth;
        }
        nav {
    position: sticky;
    top: 0;
    z-index: 1000; /* Pastikan navbar berada di atas konten lainnya */
}

  </style>

</head>

<body class="max-w-[1920px] mx-auto">
  <div class="bg-white text-black text-[15px]">
  

    <nav class="bg-white border-gray-200 dark:bg-gray-900">
      <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
          <a  class="flex items-center space-x-3 rtl:space-x-reverse">
              <img src="/assets/img/logo.png" class="h-8" alt="Flowbite Logo" />
              <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">E-Library</span>
          </a>
          <div class="flex items-center md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse">
              <button type="button" class="flex text-sm bg-gray-800 rounded-full md:me-0 focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600" id="user-menu-button" aria-expanded="false" data-dropdown-toggle="user-dropdown" data-dropdown-placement="bottom">
                  <span class="sr-only">Open user menu</span>
                  <img class="w-8 h-8 rounded-full" src="/docs/images/people/profile-picture-3.jpg" alt="user photo">
              </button>
              <!-- Dropdown menu -->
              <div class="z-50 hidden my-4 text-base list-none bg-white divide-y divide-gray-100 rounded-lg shadow dark:bg-gray-700 dark:divide-gray-600" id="user-dropdown">
                  <div class="px-4 py-3">
                      <span class="block text-sm text-gray-900 dark:text-white">Bonnie Green</span>
                      <span class="block text-sm text-gray-500 truncate dark:text-gray-400">name@flowbite.com</span>
                  </div>
                  <ul class="py-2" aria-labelledby="user-menu-button">
                      <li><a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">Dashboard</a></li>
                      <li><a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">History peminjaman</a></li>
                      <li><a href="ajuan_peminjaman.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">AJuan Peminjaman</a></li>
                      <li><a href="../admin/logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">Sign out</a></li>
                  </ul>
              </div>
              <button data-collapse-toggle="navbar-user" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-user" aria-expanded="false">
                  <span class="sr-only">Open main menu</span>
                  <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
                      <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15"/>
                  </svg>
              </button>
          </div>
          <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-user">
              <ul class="flex flex-col font-medium p-4 md:p-0 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                  <li>
                      <a href="#" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:p-0 dark:text-white" onclick="setActive(this)">Home</a>
                  </li>
                  <li>
                      <button id="dropdownNavbarLink" data-dropdown-toggle="dropdownNavbar" class="flex items-center justify-between w-full py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 md:w-auto dark:text-white md:dark:hover:text-blue-500 dark:focus:text-white dark:border-gray-700 dark:hover:bg-gray-700 md:dark:hover:bg-transparent">Category
                          <svg class="w-2.5 h-2.5 ms-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"/>
                          </svg>
                      </button>
                      <!-- Dropdown menu -->
                      <div id="dropdownNavbar" class="z-10 hidden font-normal bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700 dark:divide-gray-600">
                          <ul class="py-2 text-sm text-gray-700 dark:text-gray-400" aria-labelledby="dropdownLargeButton">
                              <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Pemrograman</a></li>
                              <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Sains</a></li>
                              <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Digital Marketing</a></li>
                              <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Cryptocurrency</a></li>
                              <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Cooking Tutorials</a></li>
                              <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Language</a></li>
                          </ul>
                      </div>
                  </li>
                  <li>
                      <a href="#Superiority" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:p-0 dark:text-white" onclick="setActive(this)">Superiority</a>
                  </li>
                  <li>
                      <a href="#faq" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:p-0 dark:text-white" onclick="setActive(this)">faq</a>
                  </li>
                  <li>
                      <a href="#contact" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:p-0 dark:text-white" onclick="setActive(this)">Contact</a>
                  </li>
              </ul>
          </div>
      </div>
  </nav>
  
  <script>
      function setActive(element) {
          // Menghapus kelas 'active' dari semua item
          const items = document.querySelectorAll('#navbar-user a');
          items.forEach(item => {
              item.classList.remove('active');
              item.classList.add('text-gray-900'); // Mengembalikan warna default
          });
  
          // Menambahkan kelas 'active' ke item yang diklik
          element.classList.add('active');
          element.classList.remove('text-gray-900'); // Mengubah warna teks saat aktif
      }
  </script>


    <div class="px-4 sm:px-10 mt-28">
      <div class="font-sans" id="Dashboard">
        <div class="text-center max-w-2xl max-md:max-w-md mx-auto">
          <div>
            <h2 class="text-gray-800 md:text-4xl text-3xl font-extrabold mb-4 md:!leading-[45px]">Welcome to Our <span class="text-blue-600">Digital Library</span> - Your Gateway to a World of Knowledge</h2>

            <p class="text-gray-600 mt-6 text-sm leading-relaxed">We're thrilled to have you here! Explore our extensive collection of books, articles, and resources that cater to your interests and curiosity. Whether you're looking to enhance your knowledge or simply enjoy a good read, our digital library is your gateway to a world of information.</p>
            <div class="grid sm:grid-cols-3 gap-6 items-center mt-12">
              <div class="flex flex-col items-center text-center">
                <h5 class="font-bold text-2xl text-blue-600 mb-2">10,000+</h5>
                <p class="text-gray-600 text-sm font-semibold">Books Available</p>
              </div>
              <div class="flex flex-col items-center text-center">
                <h5 class="font-bold text-2xl text-blue-600 mb-2">5,000+</h5>
                <p class="text-gray-600 text-sm font-semibold">Registered Users</p>
              </div>
              <div class="flex flex-col items-center text-center">
                <h5 class="font-bold text-2xl text-blue-600 mb-2">6</h5>
                <p class="text-gray-600 text-sm font-semibold">Book Categories</p>
              </div>
            </div>
      
            <div class="mt-12 flex gap-x-6 gap-y-4 justify-center max-sm:flex-col">
              <button type='button'
                class="bg-blue-600 hover:bg-transparent hover:text-blue-600 border border-blue-600 transition-all text-white font-bold text-sm rounded px-6 py-3">Start Free Access</button>
              <button type='button'
                class="bg-transparent text-gray-800 hover:bg-gray-800 hover:text-white border border-gray-800 transition-all font-bold text-sm rounded px-6 py-3">API Documentation</button>
            </div>
          </div>
        </div>
      </div>
      

      <div class="mt-28 bg-gray-50 px-4 sm:px-10 py-12" id="Category">
        <div class="max-w-7xl mx-auto">
            <div class="md:text-center max-w-2xl mx-auto">
                <h2 class="md:text-4xl text-3xl font-bold mb-6">Temukan Berbagai Kategori Buku</h2>
                <p>Jelajahi kategori buku yang beragam dan temukan bacaan yang sesuai dengan minat Anda.</p>
            </div>
            <div class="grid lg:grid-cols-3 sm:grid-cols-2 gap-10 mt-14">
                <div class="bg-white shadow-md rounded-lg p-6 text-center">
                    <svg class="w-8 h-8 text-blue-600 mb-4 mx-auto" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m8 8-4 4 4 4m8 0 4-4-4-4m-2-3-4 14"/>
                    </svg>
                    <h3 class="text-xl font-semibold mb-2">Pemrograman</h3>
                    <p>Discover the best books on programming for all skill levels, offering insights and practical guidance to enhance your coding abilities.</p>
                    <a href="../user/category/cat_pemrograman.html" class="text-blue-600 font-semibold inline-block mt-4 hover:underline">Explore Now</a>
                </div>
                <div class="bg-white shadow-md rounded-lg p-6 text-center">
                    <svg class="w-8 h-8 text-blue-600 mb-4 mx-auto" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                        <path fill-rule="evenodd" d="M5 6a3 3 0 1 1 4 2.83V9a4 4 0 0 0 4 4h.17a3.001 3.001 0 1 1 0 2H13a5.978 5.978 0 0 1-4-1.528v1.699a3.001 3.001 0 1 1-2 0V8.829A3.001 3.001 0 0 1 5 6Z" clip-rule="evenodd"/>
                    </svg>
                    <h3 class="text-xl font-semibold mb-2">Sains</h3>
                    <p>Explore the best books on science, featuring captivating insights and discoveries that spark curiosity and deepen your understanding of the world.</p>
                    <a href="javascript:void(0);" class="text-blue-600 font-semibold inline-block mt-4 hover:underline">Explore Now</a>
                </div>
                <div class="bg-white shadow-md rounded-lg p-6 text-center">
                    <svg class="w-8 h-8 text-blue-600 mb-4 mx-auto" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 16H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v1M9 12H4m8 8V9h8v11h-8Zm0 0H9m8-4a1 1 0 1 0-2 0 1 1 0 0 0 2 0Z"/>
                    </svg>
                    <h3 class="text-xl font-semibold mb-2">Digital Marketing</h3>
                    <p>Discover top books on digital marketing, offering essential strategies and insights to elevate your online presence and drive business growth.</p>
                    <a href="javascript:void(0);" class="text-blue-600 font-semibold inline-block mt-4 hover:underline">Explore Now</a>
                </div>
                <div class="bg-white shadow-md rounded-lg p-6 text-center">
                    <svg class="w-8 h-8 text-blue-600 mb-4 mx-auto" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                        <path fill-rule="evenodd" d="M9 15a6 6 0 1 1 12 0 6 6 0 0 1-12 0Zm3.845-1.855a2.4 2.4 0 0 1 1.2-1.226 1 1 0 0 1 1.992-.026c.426.15.809.408 1.111.749a1 1 0 1 1-1.496 1.327.682.682 0 0 0-.36-.213.997.997 0 0 1-.113-.032.4.4 0 0 0-.394.074.93.93 0 0 0 .455.254 2.914 2.914 0 0 1 1.504.9c.373.433.669 1.092.464 1.823a.996.996 0 0 1-.046.129c-.226.519-.627.94-1.132 1.192a1 1 0 0 1-1.956.093 2.68 2.68 0 0 1-1.227-.798 1 1 0 1 1 1.506-1.315.682.682 0 0 0 .363.216c.038.009.075.02.111.032a.4.4 0 0 0 .395-.074.93.93 0 0 0-.455-.254 2.91 2.91 0 0 1-1.503-.9c-.375-.433-.666-1.089-.466-1.817a.994.994 0 0 1 .047-.134Zm1.884.573.003.008c-.003-.005-.003-.008-.003-.008Zm.55 2.613s-.002-.002-.003-.007a.032.032 0 0 1 .003.007ZM4 14a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0v-4a1 1 0 0 1 1-1Zm3-2a1 1 0 0 1 1 1v6a1 1 0 1 1-2 0v-6a1 1 0 0 1 1-1Zm6.5-8a1 1 0 0 1 1-1H18a1 1 0 0 1 1 1v3a1 1 0 1 1-2 0v-.796l-2.341 2.049a1 1 0 0 1-1.24.06l-2.894-2.066L6.614 9.29a1 1 0 1 1-1.228-1.578l4.5-3.5a1 1 0 0 1 1.195-.025l2.856 2.04L15.34 5h-.84a1 1 0 0 1-1-1Z" clip-rule="evenodd"/>
                    </svg>
                    <h3 class="text-xl font-semibold mb-2">Cryptocurrency</h3>
                    <p>Explore leading books on cryptocurrency, providing key insights and strategies to navigate the evolving digital finance landscape.</p>
                    <a href="javascript:void(0);" class="text-blue-600 font-semibold inline-block mt-4 hover:underline">Explore Now</a>
                </div>
                <div class="bg-white shadow-md rounded-lg p-6 text-center">
                   
                    <svg class="w-8 h-8 text-blue-600 mb-4 mx-auto" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                        <path fill-rule="evenodd" d="M12 2a1 1 0 0 1 1 1v1h1a1 1 0 0 1 1 1v1h-4V3a1 1 0 0 1 1-1ZM2 7h20v2H2V7Zm1 5h18v2H3v-2Zm1 5h16v2H4v-2Z" clip-rule="evenodd"/>
                    </svg>
                    <h3 class="text-xl font-semibold mb-2">Cooking Tutorials</h3>
                    <p>Discover an array of books featuring recipes and cooking tutorials, perfect for both novice cooks and seasoned chefs looking to enhance their culinary skills.</p>
                    <a href="javascript:void(0);" class="text-blue-600 font-semibold inline-block mt-4 hover:underline">Explore Now</a>
                </div>
                <div class="bg-white shadow-md rounded-lg p-6 text-center">
                    <svg class="w-8 h-8 text-blue-600 mb-4 mx-auto" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m13 19 3.5-9 3.5 9m-6.125-2h5.25M3 7h7m0 0h2m-2 0c0 1.63-.793 3.926-2.239 5.655M7.5 6.818V5m.261 7.655C6.79 13.82 5.521 14.725 4 15m3.761-2.345L5 10m2.761 2.655L10.2 15"/>
                    </svg>
                    <h3 class="text-xl font-semibold mb-2">Language</h3>
                    <p>Explore a selection of books designed to help you learn new languages, from beginner to advanced levels, and enhance your communication skills with practical exercises and tips.</p>
                    <a href="javascript:void(0);" class="text-blue-600 font-semibold inline-block mt-4 hover:underline">Explore Now</a>
                </div>
            </div>
        </div>
    </div>
    
    
    

    <div class="mx-auto py-16 bg-white rounded-lg shadow-md mt-6" id="Superiority">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div class="max-h-full">
              <img src="https://readymadeui.com/management-img.webp" alt="Image" class="rounded-md object-cover w-full h-full" />
          </div>
          <div class="py-24">
              <h2 class="text-3xl font-extrabold text-purple-700 mb-4">Discover the Advantages of Our Digital Library</h2>
              <p class="text-gray-600 text-sm leading-6">
                  Enjoy a wealth of resources at your fingertips. Our digital library offers an immersive experience to help you learn, explore, and grow. Here’s what you can gain:
              </p>
              <ul class="list-disc text-sm text-gray-600 space-y-2 pl-4 mt-6">
                  <li>Access thousands of e-books and resources anytime, anywhere.</li>
                  <li>Personalized recommendations tailored to your interests.</li>
                  <li>Flexible borrowing system without late fees.</li>
                  <li>Interactive features like book discussions and webinars.</li>
                  <li>Rich collection for all ages, ensuring everyone finds something they love.</li>
                  <li>Integrated tools for seamless learning and research.</li>
                  <li>Accessibility features to support all users.</li>
                  <li>Statistics and tracking to monitor your reading journey.</li>
              </ul>
          </div>
      </div>
  </div>
  
  
  <div class="font-[sans-serif] bg-gray-100">
    <div class="p-4 mx-auto lg:max-w-7xl sm:max-w-full">
      <h2 class="text-4xl font-extrabold text-gray-800 mb-12">Book</h2>

      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 max-xl:gap-4 gap-6">
    <?php
    // Menghubungkan ke database
    require_once '../admin/koneksi.php';

    // Query untuk mengambil data buku dari database
    $query = "SELECT * FROM buku";
    $result = $koneksi->query($query);

    // Mengecek apakah query berhasil
    if ($result->num_rows > 0) {
        // Looping untuk setiap buku
        while ($row = $result->fetch_assoc()) {
            $kode_buku = $row['kode_buku'];
            $nama_buku = $row['nama_buku'];
            $kategori = $row['kategori'];
            $foto = $row['foto'];  // Nama file foto
            $deskripsi = $row['deskripsi'];
            ?>
            
            <div class="bg-white rounded-2xl p-5 cursor-pointer hover:-translate-y-2 transition-all relative">
                <div class="w-5/6 h-[210px] overflow-hidden mx-auto aspect-w-16 aspect-h-8 md:mb-2 mb-4">
                    <img src="../admin/uploads/<?php echo $foto; ?>" alt="<?php echo $nama_buku; ?>" class="h-full w-full object-contain" />
                </div>
                
                <div>
                    <h3 class="text-lg font-extrabold text-gray-800 book-title"><?php echo $nama_buku; ?></h3>
                    <h4 class="text-xs text-gray-400 font-light italic">cat : <?php echo $kategori; ?></h4>
                    <p class="text-gray-600 text-sm mt-2 book-description"><?php echo $deskripsi; ?></p>
                </div>
                
                <button type="button" class="w-full flex items-center justify-center gap-3 mt-6 px-6 py-3 bg-yellow-400 text-base text-gray-800 font-semibold rounded-xl" data-modal-target="static-modal" data-modal-toggle="static-modal" >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" >
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                        <circle cx="12" cy="12" r="3"/>
                    </svg>
                    View Details
                </button>
            </div>
            

            <?php
        }
    } else {
        echo "<p class='text-center text-gray-600'>Tidak ada data buku ditemukan.</p>";
    }
    ?>
</div>



      <div class="flex justify-center mt-8"> <!-- Tambahkan flex dan justify-center -->
        <button type="button" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center">
          Show more <!-- Ubah teks tombol -->
          <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
          </svg>
        </button>
      </div>
    </div>
  </div>

 <script>
 document.addEventListener('DOMContentLoaded', () => {
  const titles = document.querySelectorAll('.book-title');
  const descriptions = document.querySelectorAll('.book-description');

  titles.forEach(title => {
    const lineHeight = parseInt(getComputedStyle(title).lineHeight);
    const maxHeight = lineHeight * 2; // Menghitung tinggi maksimum untuk dua baris

    if (title.offsetHeight > maxHeight) {
      let truncatedTitle = title.innerText;

      // Memotong judul dan menambahkan "..." jika melebihi dua baris
      while (title.offsetHeight > maxHeight && truncatedTitle.length > 0) {
        truncatedTitle = truncatedTitle.slice(0, -1); // Menghapus karakter terakhir
        title.innerText = truncatedTitle + '...'; // Menambahkan "..."
      }
    }
  });

  descriptions.forEach(description => {
    const lineHeight = parseInt(getComputedStyle(description).lineHeight);
    const maxHeight = lineHeight * 2; // Menghitung tinggi maksimum untuk dua baris

    if (description.offsetHeight > maxHeight) {
      let truncatedDescription = description.innerText;

      // Memotong deskripsi dan menambahkan "..." jika melebihi dua baris
      while (description.offsetHeight > maxHeight && truncatedDescription.length > 0) {
        truncatedDescription = truncatedDescription.slice(0, -1); // Menghapus karakter terakhir
        description.innerText = truncatedDescription + '...'; // Menambahkan "..."
      }
    }
  });
});


 </script>
<!-- Modal Detail Buku -->
<!-- Modal Detail Buku -->
<div id="static-modal" data-modal-backdrop="static" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed inset-0 z-50 justify-center items-center w-full h-full">
    <div class="relative p-4 w-full max-w-2xl max-h-full">
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
            <!-- Modal header -->
            <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                <h3  class="text-xl font-semibold text-gray-900 dark:text-white">
                Detail Buku
                </h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="static-modal">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <div class="p-4 md:p-5 space-y-4 flex">
                <div class="w-1/3">
                    <img id="modalBookImage" src="../admin/uploads/<?php echo $foto; ?>" alt="Buku" class="h-[250px] w-[200px] mx-auto object-contain">
                </div>
                <div class="w-2/3 pl-4">
                    <h3 id="modalBookTitle" class="text-xl font-bold text-gray-800 mb-2"><?php echo $nama_buku; ?></h3>
                    <p id="modalBookCategory" class="text-sm text-gray-500 italic mb-2">cat : <?php echo $kategori; ?></p>
                    <hr class="border-gray-300 my-4">
                    <p id="modalBookDescription" class="text-gray-700 text-sm"><?php echo $deskripsi; ?></p>
                </div>
            </div>
            <!-- Modal footer -->
            <form id="bookForm" action="persetujuan.php" method="GET" class="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                <!-- Hidden input untuk nama buku -->
                <input type="hidden" id="bookName" name="bookName" value="">

                <button type="submit" id="ajukanBtn" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                    Ajukan
                </button>
                <button type="button" class="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700" data-modal-hide="static-modal">
                    Close
                </button>
            </form>
        </div>
    </div>
</div>

<script>
    // Pastikan tombol "Ajukan" memiliki event listener yang benar
    document.getElementById("ajukanBtn").addEventListener("click", function(event) {
        // Mengambil nama buku dari modal
        const bookName = document.getElementById("modalBookTitle").innerText;

        // Menambahkan nama buku ke dalam input hidden sebelum form disubmit
        document.getElementById("bookName").value = bookName;
    });
</script>


    <script>
        // Pastikan tombol "Ajukan" memiliki event listener yang benar
        document.getElementById("ajukanBtn").addEventListener("click", function() {
            // Arahkan ke halaman baru (form peminjaman buku)
            window.location.href = "persetujuan.php";  // Ganti dengan path ke file form peminjaman
        });
    </script>


      <div class="mt-28">
        <h2 class="md:text-4xl text-3xl font-bold text-center mb-14">Application Metrics</h2>
        <div class="px-6 py-2 font-sans">
          <div class="grid lg:grid-cols-4 sm:grid-cols-2 gap-x-6 gap-y-10 max-w-6xl mx-auto">
            <div class="flex items-center gap-6">
              <svg xmlns="http://www.w3.org/2000/svg" class="fill-orange-500 w-14 inline-block shrink-0" viewBox="0 0 512 512">
                <path d="M437 268.152h-50.118c-6.821 0-13.425.932-19.71 2.646-12.398-24.372-37.71-41.118-66.877-41.118h-88.59c-29.167 0-54.479 16.746-66.877 41.118a74.798 74.798 0 0 0-19.71-2.646H75c-41.355 0-75 33.645-75 75v80.118c0 24.813 20.187 45 45 45h422c24.813 0 45-20.187 45-45v-80.118c0-41.355-33.645-75-75-75zm-300.295 36.53v133.589H45c-8.271 0-15-6.729-15-15v-80.118c0-24.813 20.187-45 45-45h50.118c4.072 0 8.015.553 11.769 1.572a75.372 75.372 0 0 0-.182 4.957zm208.59 133.589h-178.59v-133.59c0-24.813 20.187-45 45-45h88.59c24.813 0 45 20.187 45 45v133.59zm136.705-15c0 8.271-6.729 15-15 15h-91.705v-133.59a75.32 75.32 0 0 0-.182-4.957 44.899 44.899 0 0 1 11.769-1.572H437c24.813 0 45 20.187 45 45v80.119z" data-original="#000000" />
                <path d="M100.06 126.504c-36.749 0-66.646 29.897-66.646 66.646-.001 36.749 29.897 66.646 66.646 66.646 36.748 0 66.646-29.897 66.646-66.646s-29.897-66.646-66.646-66.646zm-.001 103.292c-20.207 0-36.646-16.439-36.646-36.646s16.439-36.646 36.646-36.646 36.646 16.439 36.646 36.646-16.439 36.646-36.646 36.646zM256 43.729c-49.096 0-89.038 39.942-89.038 89.038s39.942 89.038 89.038 89.038 89.038-39.942 89.038-89.038c0-49.095-39.942-89.038-89.038-89.038zm0 148.076c-32.554 0-59.038-26.484-59.038-59.038 0-32.553 26.484-59.038 59.038-59.038s59.038 26.484 59.038 59.038c0 32.554-26.484 59.038-59.038 59.038zm155.94-65.301c-36.748 0-66.646 29.897-66.646 66.646.001 36.749 29.898 66.646 66.646 66.646 36.749 0 66.646-29.897 66.646-66.646s-29.897-66.646-66.646-66.646zm0 103.292c-20.206 0-36.646-16.439-36.646-36.646.001-20.207 16.44-36.646 36.646-36.646 20.207 0 36.646 16.439 36.646 36.646s-16.439 36.646-36.646 36.646z" data-original="#000000" />
              </svg>
              <div>
                <h3 class="text-gray-500 text-4xl font-bold">400+</h3>
                <p class="text-base text-gray-400 mt-2">Unique Visitors</p>
              </div>
            </div>
            <div class="flex items-center gap-6">
              <svg xmlns="http://www.w3.org/2000/svg" class="fill-orange-500 w-14 inline-block shrink-0" viewBox="0 0 512 512">
                <path fill-rule="evenodd" d="M64.217 333.491h41.421c5.508 0 10 4.492 10 10v97.833c0 5.508-4.492 10-10 10H64.217c-5.508 0-10-4.492-10-10v-97.833c0-5.508 4.492-10 10-10zm155.471-61.737h-41.422c-5.508 0-10 4.492-10 10v159.571c0 5.508 4.492 10 10 10h41.422c5.508 0 10-4.492 10-10V281.754c0-5.508-4.493-10-10-10zm114.049-64.466h-41.421c-5.508 0-10 4.492-10 10v224.036c0 5.508 4.492 10 10 10h41.421c5.508 0 10-4.492 10-10V217.288c-.001-5.507-4.493-10-10-10zm72.625-57.992h41.421c5.508 0 10 4.492 10 10v282.028c0 5.508-4.492 10-10 10h-41.421c-5.508 0-10-4.492-10-10V159.296c0-5.508 4.492-10 10-10zm2.707-106.018a7.98 7.98 0 0 1-.812-15.938l49.121-2.666a7.98 7.98 0 0 1 8.307 9.094l.006.001-7.088 48.68a7.986 7.986 0 0 1-15.812-2.25l3.878-26.632C385.642 108.019 321.72 152.702 257.158 189.5c-69.131 39.402-138.98 69.744-206.779 93.355a7.976 7.976 0 0 1-5.25-15.062c66.943-23.313 135.906-53.269 204.154-92.167 63.527-36.208 126.449-80.188 186.56-133.799zM45.262 481.873h421.477c5.508 0 10 4.492 10 10v3.193c0 5.508-4.492 10-10 10H45.262c-5.508 0-10-4.492-10-10v-3.193c0-5.508 4.492-10 10-10zM139.587 6.935c-48.325 0-87.5 39.175-87.5 87.5s39.175 87.5 87.5 87.5 87.5-39.175 87.5-87.5c-.001-48.325-39.176-87.5-87.5-87.5zm-8 32.13v5.279c-5.474 1.183-10.606 3.537-14.768 6.92-6.626 5.387-10.827 13.21-10.353 22.965.476 9.817 5.372 16.4 12.186 20.849 5.887 3.844 13.093 5.827 19.733 6.917 5.206.855 10.757 2.201 14.95 4.733 3.261 1.969 5.71 4.838 6.23 9.127.072.595.111 1.013.117 1.26.08 3.359-1.536 5.926-3.962 7.767-3.135 2.379-7.564 3.785-12.005 4.324a33.57 33.57 0 0 1-3.172.254c-5.25.126-10.424-1.156-14.458-3.842-3.274-2.18-5.775-5.367-6.818-9.552a7.982 7.982 0 0 0-15.5 3.812c2.094 8.399 7.044 14.749 13.505 19.052 4.252 2.831 9.164 4.736 14.315 5.711v5.165a8 8 0 1 0 16-.001v-5.01c6.309-1.038 12.699-3.388 17.758-7.226 6.302-4.782 10.494-11.632 10.275-20.829a29.17 29.17 0 0 0-.179-2.76c-1.22-10.052-6.653-16.591-13.856-20.94-6.27-3.786-13.768-5.668-20.637-6.796-4.832-.793-9.912-2.13-13.607-4.543-2.767-1.806-4.752-4.416-4.937-8.224-.202-4.157 1.615-7.512 4.478-9.84 2.281-1.854 5.196-3.144 8.362-3.781a22.978 22.978 0 0 1 10.115.244c5.278 1.338 10.083 4.817 12.614 10.845a7.997 7.997 0 0 0 10.469 4.281 7.997 7.997 0 0 0 4.281-10.469c-4.701-11.196-13.65-17.664-23.489-20.158a37.3 37.3 0 0 0-1.646-.377v-5.161a8 8 0 1 0-16.001.004z" clip-rule="evenodd" data-original="#000000" />
              </svg>
              <div>
                <h3 class="text-gray-500 text-4xl font-bold">450+</h3>
                <p class="text-base text-gray-400 mt-2">Total Sales</p>
              </div>
            </div>
            <div class="flex items-center gap-6">
              <svg xmlns="http://www.w3.org/2000/svg" class="fill-orange-500 w-14 inline-block shrink-0" viewBox="0 0 28 28">
                <path d="M18.56 16.94h-3.12l.65-2.16a2.58 2.58 0 0 0-1.66-3.21 1.41 1.41 0 0 0-1.81 1l-.1.42a8.61 8.61 0 0 1-2.26 4l-.57.56a1.56 1.56 0 0 0-1.21-.59h-.73a1.56 1.56 0 0 0-1.56 1.54v6.44a1.56 1.56 0 0 0 1.56 1.56h.73a1.55 1.55 0 0 0 1.33-.76l.14.07a6.55 6.55 0 0 0 2.91.69h3.59a3.58 3.58 0 0 0 3-1.6 6.34 6.34 0 0 0 1.07-3.53v-2.49a1.94 1.94 0 0 0-1.96-1.94zm-9.56 8a.56.56 0 0 1-.56.56h-.69a.56.56 0 0 1-.56-.56V18.5a.56.56 0 0 1 .56-.56h.73a.56.56 0 0 1 .52.56zm10.5-3.57a5.38 5.38 0 0 1-.9 3 2.59 2.59 0 0 1-2.15 1.15h-3.59a5.53 5.53 0 0 1-2.46-.58l-.4-.2V18.6l.92-.92a9.63 9.63 0 0 0 2.53-4.46l.1-.41a.43.43 0 0 1 .2-.26.4.4 0 0 1 .32 0 1.58 1.58 0 0 1 1 2l-.84 2.81a.5.5 0 0 0 .08.44.48.48 0 0 0 .4.2h3.79a.94.94 0 0 1 .94.94zM11 7.3l-.32 1.85a1.09 1.09 0 0 0 .44 1.09 1.11 1.11 0 0 0 .65.22 1.18 1.18 0 0 0 .52-.13L14 9.45l1.67.88a1.1 1.1 0 0 0 1.17-.09 1.09 1.09 0 0 0 .44-1.08L17 7.3 18.31 6a1.1 1.1 0 0 0 .29-1.14 1.12 1.12 0 0 0-.9-.76l-1.87-.27L15 2.12a1.12 1.12 0 0 0-2 0l-.83 1.69-1.87.27a1.12 1.12 0 0 0-.9.76A1.1 1.1 0 0 0 9.69 6zm-.6-2.23 2.13-.31a.49.49 0 0 0 .47-.27l1-1.93a.11.11 0 0 1 .2 0l1 1.93a.49.49 0 0 0 .38.27l2.13.31a.12.12 0 0 1 .09.08.11.11 0 0 1 0 .11l-1.54 1.5a.53.53 0 0 0-.15.45l.37 2.11a.09.09 0 0 1-.05.11.1.1 0 0 1-.12 0l-1.9-1a.47.47 0 0 0-.46 0l-1.91 1a.09.09 0 0 1-.11 0 .09.09 0 0 1-.05-.11l.37-2.11a.53.53 0 0 0-.15-.45l-1.54-1.5a.11.11 0 0 1 0-.11.12.12 0 0 1-.12-.08zm-3.06 8.18a1 1 0 0 0 1-1.19l-.27-1.52 1.12-1.09a1 1 0 0 0-.56-1.73L7.1 7.5l-.69-1.39a1.05 1.05 0 0 0-1.82 0L3.9 7.5l-1.53.22a1 1 0 0 0-.56 1.73l1.11 1.09-.27 1.52a1 1 0 0 0 .41 1 1 1 0 0 0 1.07.07l1.37-.72 1.37.72a1 1 0 0 0 .47.12zm-1.84-1.9a.46.46 0 0 0-.23.06l-1.63.82.36-1.78a.53.53 0 0 0-.2-.45L2.51 8.71l1.8-.26a.47.47 0 0 0 .37-.27l.83-1.63.81 1.63a.47.47 0 0 0 .37.27l1.8.29L7.2 10a.53.53 0 0 0-.15.45l.29 1.8-1.61-.84a.46.46 0 0 0-.23-.06zm20.95-2.94a1 1 0 0 0-.82-.69L24.1 7.5l-.69-1.39a1.05 1.05 0 0 0-1.82 0L20.9 7.5l-1.53.22a1 1 0 0 0-.56 1.73l1.11 1.09-.27 1.52a1 1 0 0 0 .41 1 1 1 0 0 0 1.07.07l1.37-.72 1.37.72a1 1 0 0 0 .47.12 1 1 0 0 0 1-1.19l-.27-1.52 1.11-1.09a1 1 0 0 0 .27-1.04zM24.2 10a.53.53 0 0 0-.15.45l.29 1.8-1.61-.84a.47.47 0 0 0-.46 0l-1.63.82.36-1.78a.53.53 0 0 0-.2-.45l-1.29-1.29 1.8-.26a.47.47 0 0 0 .37-.27l.83-1.63.81 1.63a.47.47 0 0 0 .37.27l1.8.29z" data-name="Layer 2" data-original="#000000" />
              </svg>
              <div>
                <h3 class="text-gray-500 text-4xl font-bold">500+</h3>
                <p class="text-base text-gray-400 mt-2">Customer Satisfaction</p>
              </div>
            </div>
            <div class="flex items-center gap-6">
              <svg xmlns="http://www.w3.org/2000/svg" class="fill-orange-500 w-14 inline-block shrink-0" viewBox="0 0 512 512">
                <path d="M477.797 290.203c0 59.244-23.071 114.942-64.963 156.834S315.244 512 256 512s-114.942-23.071-156.834-64.963-64.963-97.59-64.963-156.834c0-39.621 10.579-78.512 30.595-112.468 19.419-32.944 47.178-60.48 80.276-79.63 7.646-4.427 17.437-1.814 21.861 5.836 4.426 7.648 1.813 17.437-5.836 21.861-53.882 31.175-88.951 87.036-94.189 148.4H84.6c8.837 0 16 7.163 16 16s-7.163 16-16 16H66.884C74.594 398.12 148.083 471.609 240 479.319v-17.717c0-8.837 7.163-16 16-16s16 7.163 16 16v17.717c91.917-7.71 165.406-81.199 173.116-173.116h-17.717c-8.837 0-16-7.163-16-16s7.163-16 16-16h17.69c-5.238-61.364-40.307-117.227-94.19-148.4-7.648-4.425-10.262-14.212-5.836-21.861 4.425-7.648 14.214-10.261 21.861-5.836 33.098 19.148 60.857 46.685 80.277 79.63 20.016 33.955 30.596 72.846 30.596 112.467zm-253.173-220.2 15.259-15.259-.258 71.899c-.031 8.837 7.106 16.025 15.942 16.058h.059c8.81 0 15.967-7.126 15.999-15.942l.259-72.248 15.492 15.492c3.124 3.124 7.219 4.687 11.313 4.687s8.189-1.563 11.313-4.687c6.248-6.248 6.248-16.379 0-22.627L267.313 4.687c-6.248-6.248-16.379-6.248-22.627 0l-42.689 42.689c-6.248 6.248-6.248 16.379 0 22.627s16.379 6.248 22.627 0zM272 174.358v64.628c16.74 5.24 29.977 18.478 35.218 35.217h50.493c8.837 0 16 7.163 16 16s-7.163 16-16 16h-50.493c-6.823 21.795-27.202 37.655-51.218 37.655-29.585 0-53.654-24.069-53.654-53.655 0-24.015 15.86-44.394 37.654-51.217v-64.628c0-8.837 7.163-16 16-16s16 7.163 16 16zm5.655 115.845c0-11.94-9.715-21.654-21.655-21.654s-21.654 9.714-21.654 21.654 9.714 21.655 21.654 21.655 21.655-9.714 21.655-21.655z" data-original="#000000" />
              </svg>
              <div>
                <h3 class="text-gray-500 text-4xl font-bold">600+</h3>
                <p class="text-base text-gray-400 mt-2">System Uptime</p>
              </div>
            </div>
          </div>
        </div>
      </div>


    
    

    <div class="mt-28 bg-gray-50 px-4 sm:px-10 py-12 space-y-6" id="faq">
      <div class="md:text-center max-w-2xl mx-auto mb-14">
          <h2 class="md:text-4xl text-3xl font-bold mb-6">Frequently Asked Questions</h2>
          <p>Explore common questions and find answers to help you make the most out of our services. If you don't see your question here, feel free to contact us for assistance.</p>
      </div>
      <div class="shadow-[0_2px_10px_-3px_rgba(6,81,237,0.3)] border-2 border-transparent rounded-md transition-all" role="accordion">
          <button type="button" class="w-full font-semibold text-left py-5 px-6 flex items-center" onclick="this.nextElementSibling.classList.toggle('hidden')">
              <span class="text-base mr-4">What resources are available in the digital library?</span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-4 fill-current ml-auto shrink-0 rotate-180" viewBox="0 0 24 24">
                  <path fill-rule="evenodd" d="M11.99997 18.1669a2.38 2.38 0 0 1-1.68266-.69733l-9.52-9.52a2.38 2.38 0 1 1 3.36532-3.36532l7.83734 7.83734 7.83734-7.83734a2.38 2.38 0 1 1 3.36532 3.36532l-9.52 9.52a2.38 2.38 0 0 1-1.68266.69734z" clip-rule="evenodd"></path>
              </svg>
          </button>
          <div class="hidden pb-5 px-6">
              <p>Our digital library offers e-books, research papers, audiobooks, and various multimedia resources.</p>
          </div>
      </div>
      <div class="shadow-[0_2px_10px_-3px_rgba(6,81,237,0.3)] border-2 border-transparent hover:border-blue-600 rounded-md transition-all" role="accordion">
          <button type="button" class="w-full font-semibold text-left py-5 px-6 flex items-center" onclick="this.nextElementSibling.classList.toggle('hidden')">
              <span class="text-base mr-4">How do I register for a library account?</span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-4 fill-current ml-auto shrink-0 -rotate-90" viewBox="0 0 24 24">
                  <path fill-rule="evenodd" d="M11.99997 18.1669a2.38 2.38 0 0 1-1.68266-.69733l-9.52-9.52a2.38 2.38 0 1 1 3.36532-3.36532l7.83734 7.83734 7.83734-7.83734a2.38 2.38 0 1 1 3.36532 3.36532l-9.52 9.52a2.38 2.38 0 0 1-1.68266.69734z" clip-rule="evenodd"></path>
              </svg>
          </button>
          <div class="hidden pb-5 px-6">
              <p>You can register for a library account by filling out the registration form on our website.</p>
          </div>
      </div>
      <div class="shadow-[0_2px_10px_-3px_rgba(6,81,237,0.3)] border-2 border-transparent hover:border-blue-600 rounded-md transition-all" role="accordion">
          <button type="button" class="w-full font-semibold text-left py-5 px-6 flex items-center" onclick="this.nextElementSibling.classList.toggle('hidden')">
              <span class="text-base mr-4">Can I download e-books for offline reading?</span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-4 fill-current ml-auto shrink-0 -rotate-90" viewBox="0 0 24 24">
                  <path fill-rule="evenodd" d="M11.99997 18.1669a2.38 2.38 0 0 1-1.68266-.69733l-9.52-9.52a2.38 2.38 0 1 1 3.36532-3.36532l7.83734 7.83734 7.83734-7.83734a2.38 2.38 0 1 1 3.36532 3.36532l-9.52 9.52a2.38 2.38 0 0 1-1.68266.69734z" clip-rule="evenodd"></path>
              </svg>
          </button>
          <div class="hidden pb-5 px-6">
              <p>Yes, many of our e-books are available for download to read offline.</p>
          </div>
      </div>
      <div class="shadow-[0_2px_10px_-3px_rgba(6,81,237,0.3)] border-2 border-transparent hover:border-blue-600 rounded-md transition-all" role="accordion">
          <button type="button" class="w-full font-semibold text-left py-5 px-6 flex items-center" onclick="this.nextElementSibling.classList.toggle('hidden')">
              <span class="text-base mr-4">How do I return borrowed materials?</span>
              <svg xmlns="http://www.w3.org/2000/svg" class="w-4 fill-current ml-auto shrink-0 -rotate-90" viewBox="0 0 24 24">
                  <path fill-rule="evenodd" d="M11.99997 18.1669a2.38 2.38 0 0 1-1.68266-.69733l-9.52-9.52a2.38 2.38 0 1 1 3.36532-3.36532l7.83734 7.83734 7.83734-7.83734a2.38 2.38 0 1 1 3.36532 3.36532l-9.52 9.52a2.38 2.38 0 0 1-1.68266.69734z" clip-rule="evenodd"></path>
              </svg>
          </button>
          <div class="hidden pb-5 px-6">
              <p>You can return borrowed materials directly through your library account online.</p>
          </div>
      </div>
  </div>
  


    </div>

    <footer class="bg-blue-500 p-10 font-[sans-serif] tracking-wide" id="contact">
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        <div class="lg:flex lg:items-center">
          <a href="javascript:void(0)">
            <img src="https://readymadeui.com/readymadeui-light.svg" alt="logo" class="w-52" />
          </a>
        </div>

        <div class="lg:flex lg:items-center">
          <ul class="flex space-x-6">
            <li>
              <a href="javascript:void(0)">
                <svg xmlns="http://www.w3.org/2000/svg" class="fill-gray-300 hover:fill-white w-7 h-7" viewBox="0 0 24 24">
                  <path fill-rule="evenodd"
                    d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7v-7h-2v-3h2V8.5A3.5 3.5 0 0 1 15.5 5H18v3h-2a1 1 0 0 0-1 1v2h3v3h-3v7h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"
                    clip-rule="evenodd" />
                </svg>
              </a>
            </li>
            <li>
              <a href="javascript:void(0)">
                <svg xmlns="http://www.w3.org/2000/svg" class="fill-gray-300 hover:fill-white w-7 h-7" viewBox="0 0 24 24">
                  <path fill-rule="evenodd"
                    d="M21 5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5zm-2.5 8.2v5.3h-2.79v-4.93a1.4 1.4 0 0 0-1.4-1.4c-.77 0-1.39.63-1.39 1.4v4.93h-2.79v-8.37h2.79v1.11c.48-.78 1.47-1.3 2.32-1.3 1.8 0 3.26 1.46 3.26 3.26zM6.88 8.56a1.686 1.686 0 0 0 0-3.37 1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68zm1.39 1.57v8.37H5.5v-8.37h2.77z"
                    clip-rule="evenodd" />
                </svg>
              </a>
            </li>
            <li>
              <a href="javascript:void(0)">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="fill-gray-300 hover:fill-white w-7 h-7"
                  viewBox="0 0 24 24">
                  <path
                    d="M22.92 6c-.77.35-1.6.58-2.46.69.88-.53 1.56-1.37 1.88-2.38-.83.5-1.75.85-2.72 1.05C18.83 4.5 17.72 4 16.46 4c-2.35 0-4.27 1.92-4.27 4.29 0 .34.04.67.11.98-3.56-.18-6.73-1.89-8.84-4.48-.37.63-.58 1.37-.58 2.15 0 1.49.75 2.81 1.91 3.56-.71 0-1.37-.2-1.95-.5v.03c0 2.08 1.48 3.82 3.44 4.21a4.22 4.22 0 0 1-1.93.07 4.28 4.28 0 0 0 4 2.98 8.521 8.521 0 0 1-5.33 1.84c-.34 0-.68-.02-1.02-.06C3.9 20.29 6.16 21 8.58 21c7.88 0 12.21-6.54 12.21-12.21 0-.19 0-.37-.01-.56.84-.6 1.56-1.36 2.14-2.23z" />
                </svg>
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h4 class="text-lg font-semibold mb-6 text-white">Contact Us</h4>
          <ul class="space-y-4">
            <li>
              <a href="javascript:void(0)" class="text-gray-300 hover:text-white text-sm">Email</a>
            </li>
            <li>
              <a href="javascript:void(0)" class="text-gray-300 hover:text-white text-sm">Phone</a>
            </li>
            <li>
              <a href="javascript:void(0)" class="text-gray-300 hover:text-white text-sm">Address</a>
            </li>
          </ul>
        </div>

        <div>
          <h4 class="text-lg font-semibold mb-6 text-white">Information</h4>
          <ul class="space-y-4">
            <li>
              <a href="javascript:void(0)" class="text-gray-300 hover:text-white text-sm">About Us</a>
            </li>
            <li>
              <a href="javascript:void(0)" class="text-gray-300 hover:text-white text-sm">Terms &amp; Conditions</a>
            </li>
            <li>
              <a href="javascript:void(0)" class="text-gray-300 hover:text-white text-sm">Privacy Policy</a>
            </li>
          </ul>
        </div>
      </div>

      <p class='text-gray-300 text-sm mt-10'>© ReadymadeUI. All rights reserved.
      </p>
    </footer>

  </div>

  <!-- <script>

    var toggleOpen = document.getElementById('toggleOpen');
    var toggleClose = document.getElementById('toggleClose');
    var collapseMenu = document.getElementById('collapseMenu');

    function handleClick() {
      if (collapseMenu.style.display === 'block') {
        collapseMenu.style.display = 'none';
      } else {
        collapseMenu.style.display = 'block';
      }
    }

    toggleOpen.addEventListener('click', handleClick);
    toggleClose.addEventListener('click', handleClick);

  </script> -->
  <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>

  <script type="text/javascript">
    // Jika halaman ini dimuat ulang setelah login, redirect ke halaman dashboard
    if (performance.navigation.type == 2) {  // Cek apakah halaman dimuat ulang dengan tombol "Back"
        window.location.href = "../index.php";  // Redirect ke halaman dashboard
    }
</script>
</body>

</html>