<?php
// Mulai session
session_start();

// Menghubungkan ke database
include '../admin/koneksi.php';

// Ambil nama buku dari query string
$bookName = isset($_GET['bookName']) ? $_GET['bookName'] : '';

// Mengecek apakah pengguna sudah login
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    // Query untuk mendapatkan data pengguna berdasarkan email
    $query = "SELECT * FROM akun WHERE email = '$email'";
    $result = mysqli_query($koneksi, $query);

    // Jika data ditemukan
    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        $nama_lengkap = $data['fullname']; // Pastikan kolom ini sesuai dengan database
        $email_pengguna = $data['email'];
    } else {
        // Jika data tidak ditemukan, arahkan ke halaman login
        header("Location: login.php");
        exit();
    }

    // Query untuk mengecek apakah ada peminjaman aktif untuk buku ini
    $checkQuery = "SELECT * FROM data_request WHERE email = '$email' AND book_name = '$bookName' AND status = 'Aktif'";
    $checkResult = mysqli_query($koneksi, $checkQuery);

    // Jika ada peminjaman aktif untuk buku ini
    if (mysqli_num_rows($checkResult) > 0) {
        $isBorrowingActive = true;
    } else {
        $isBorrowingActive = false;
    }
} else {
    // Jika belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Persetujuan Peminjaman Buku</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">
    <div class="flex justify-center items-center min-h-screen">
        <div class="max-w-lg w-full bg-white p-6 rounded-lg shadow-lg">
            <h3 class="text-3xl font-semibold text-center text-gray-800 mb-6">Form Persetujuan Peminjaman Buku</h3>

            <!-- Form Input -->
            <form action="submit_peminjaman.php" method="POST">
                <div class="mb-4">
                    <label for="name" class="block text-gray-700">Nama</label>
                    <input type="text" id="name" name="name" class="w-full px-4 py-2 mt-2 border border-gray-300 rounded-md" value="<?php echo htmlspecialchars($nama_lengkap); ?>" required readonly>
                </div>

                <div class="mb-4">
                    <label for="email" class="block text-gray-700">Email</label>
                    <input type="email" id="email" name="email" class="w-full px-4 py-2 mt-2 border border-gray-300 rounded-md" value="<?php echo htmlspecialchars($email_pengguna); ?>" required readonly>
                </div>

                <div class="mb-4">
                    <label for="bookName" class="block text-gray-700">Nama Buku</label>
                    <input type="text" id="bookName" name="bookName" class="w-full p-2 border border-gray-300 rounded-md" value="<?php echo htmlspecialchars($bookName); ?>" readonly />
                </div>

                <!-- Tanggal Peminjaman -->
                <div class="mb-4">
                    <label for="borrowDate" class="block text-gray-700">Tanggal Peminjaman</label>
                    <input type="date" id="borrowDate" name="borrowDate" class="w-full px-4 py-2 mt-2 border border-gray-300 rounded-md" value="<?php echo date('Y-m-d'); ?>" required readonly>
                </div>

                <!-- Input Lama Peminjaman -->
                <div class="mb-4">
                    <label for="borrowDuration" class="block text-gray-700">Lama Peminjaman (dalam hari)</label>
                    <input type="number" id="borrowDuration" name="borrowDuration" class="w-full px-4 py-2 mt-2 border border-gray-300 rounded-md" placeholder="Masukkan lama peminjaman" required max="30" />
                    <small class="text-gray-500">Maksimal 30 hari</small>
                </div>

                <!-- Tanggal Pengembalian -->
                <div class="mb-4">
                    <label for="returnDate" class="block text-gray-700">Tanggal Pengembalian</label>
                    <input type="date" id="returnDate" name="returnDate" class="w-full px-4 py-2 mt-2 border border-gray-300 rounded-md" required readonly />
                </div>

                
                <div class="flex justify-between mt-6">
                    <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 px-6 py-2 rounded-md">
                        Kirim
                    </button>
                    <button type="button" id="backBtn" class="text-gray-600 bg-gray-200 hover:bg-gray-300 px-6 py-2 rounded-md">
                        Kembali
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Peringatan (Akan muncul jika ada peminjaman aktif) -->
    <?php if ($isBorrowingActive): ?>
        <div id="warningModal" class="fixed inset-0 bg-gray-500 bg-opacity-50 flex justify-center items-center">
            <div class="bg-white p-6 rounded-md shadow-lg max-w-md w-full">
                <h4 class="text-xl font-semibold mb-4">Peringatan</h4>
                <p class="text-gray-700 mb-4">Anda tidak dapat mengajukan peminjaman buku ini lagi karena Anda masih dalam masa peminjaman buku ini.</p>
                <div class="flex justify-end">
                    <button onclick="window.location.href='cek_peminjaman.php'" class="px-4 py-2 bg-blue-600 text-white rounded-md">
                        Cek Peminjaman
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <script>
        // Menghitung tanggal pengembalian berdasarkan lama peminjaman
        $(document).ready(function() {
            $('#borrowDuration').on('input', function() {
                var borrowDuration = parseInt($(this).val());
                if (borrowDuration && borrowDuration <= 30) {
                    var borrowDate = $('#borrowDate').val();
                    var returnDate = new Date(borrowDate);
                    returnDate.setDate(returnDate.getDate() + borrowDuration);
                    var returnDateString = returnDate.toISOString().split('T')[0];
                    $('#returnDate').val(returnDateString);
                }
            });
        });

        // Fungsi untuk mengecek apakah user sudah login atau belum
        function isUserLoggedIn() {
            <?php
                if (isset($_SESSION['email'])) {
                    echo 'return true;';
                } else {
                    echo 'return false;';
                }
            ?>
        }

        // Ketika tombol "Kembali" diklik
        document.getElementById('backBtn').addEventListener('click', function () {
            if (isUserLoggedIn()) {
                window.location.href = 'index.php';
            } else {
                window.location.href = './index.php';
            }
        });
    </script>
</body>

</html>
